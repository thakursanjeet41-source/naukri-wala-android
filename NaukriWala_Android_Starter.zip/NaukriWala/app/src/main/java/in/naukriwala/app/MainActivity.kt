package in.naukriwala.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Job(val title: String, val company: String, val location: String, val type: String)

private val sampleJobs = listOf(
    Job("Office Assistant", "Naukri Wala Demo Employer", "Jamshedpur, Jharkhand", "Full time"),
    Job("Delivery Executive", "Demo Logistics", "Patna, Bihar", "Full time"),
    Job("Computer Operator", "Demo Services", "Ranchi, Jharkhand", "Full time")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NaukriWalaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NaukriWalaApp() {
    var page by remember { mutableStateOf("home") }
    var language by remember { mutableStateOf("English") }
    var query by remember { mutableStateOf("") }
    var selectedJob by remember { mutableStateOf<Job?>(null) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF155EEF),
            secondary = androidx.compose.ui.graphics.Color(0xFF12B76A)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Naukri Wala", fontWeight = FontWeight.Bold)
                            Text("Find work. Build your future.", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        TextButton(onClick = { language = if (language == "English") "हिन्दी" else "English" }) {
                            Text(language)
                        }
                    },
                    navigationIcon = {
                        if (page != "home") {
                            IconButton(onClick = { page = "home"; selectedJob = null }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }
                    }
                )
            }
        ) { padding ->
            when (page) {
                "home" -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    query = query,
                    onQuery = { query = it },
                    onCandidate = { page = "candidate" },
                    onEmployer = { page = "employer" },
                    onAdmin = { page = "admin" },
                    onJob = { selectedJob = it; page = "details" }
                )
                "candidate" -> RegistrationScreen(Modifier.padding(padding), "Candidate", "Create your job seeker account")
                "employer" -> RegistrationScreen(Modifier.padding(padding), "Employer", "Register your company to post vacancies")
                "admin" -> AdminScreen(Modifier.padding(padding))
                "details" -> JobDetailsScreen(Modifier.padding(padding), selectedJob)
            }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier,
    query: String,
    onQuery: (String) -> Unit,
    onCandidate: () -> Unit,
    onEmployer: () -> Unit,
    onAdmin: () -> Unit,
    onJob: (Job) -> Unit
) {
    val jobs = sampleJobs.filter {
        (it.title + it.company + it.location).contains(query, ignoreCase = true)
    }
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Your next opportunity starts here", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Explore jobs across India. Register as a candidate or employer.")
                }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Search job, company or location") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onCandidate, modifier = Modifier.weight(1f)) { Text("I need a job") }
                OutlinedButton(onClick = onEmployer, modifier = Modifier.weight(1f)) { Text("I'm hiring") }
            }
        }
        item { Text("Latest job listings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (jobs.isEmpty()) {
            item { Text("No matching demo jobs. Try another search.") }
        } else {
            items(jobs) { job ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onJob(job) },
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(job.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(job.company)
                        Text("${job.location} • ${job.type}", style = MaterialTheme.typography.bodySmall)
                        Text("View details →", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) {
                Text("Admin preview (demo only)")
            }
        }
        item {
            Text(
                "Demo build: listings and forms are sample screens. Real accounts, applications and admin approvals require Firebase setup.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun RegistrationScreen(modifier: Modifier, role: String, subtitle: String) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    Column(
        modifier = modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("$role Registration", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle)
        OutlinedTextField(name, { name = it }, label = { Text(if (role == "Employer") "Contact person / company name" else "Full name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {}, modifier = Modifier.fillMaxWidth(), enabled = false) {
            Text("Registration will be enabled after Firebase setup")
        }
        Text("This is a UI preview. Do not enter real personal information in this demo.")
    }
}

@Composable
fun JobDetailsScreen(modifier: Modifier, job: Job?) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(job?.title ?: "Job details", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(job?.company.orEmpty())
        Text(job?.location.orEmpty())
        Text(job?.type.orEmpty())
        Text("Application submission will be enabled after account and backend integration.")
    }
}

@Composable
fun AdminScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Admin dashboard preview", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Pending employer approvals: Demo")
        Text("Pending job approvals: Demo")
        Text("Admin access must be protected by Firebase role-based security. This preview is not an operational admin panel.")
    }
}
