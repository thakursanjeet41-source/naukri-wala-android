# Naukri Wala – Android starter project

This is the initial Android UI starter for the Naukri Wala job portal.

## Included
- Kotlin + Jetpack Compose Android app
- Home screen and sample job cards
- Candidate and employer registration UI previews
- Job details screen
- Admin dashboard preview
- English/Hindi language toggle placeholder

## Not yet implemented
This is NOT a production-ready job portal yet. Firebase authentication, Firestore database,
resume upload, real job posting/application flows, server-side admin authorization,
notifications, privacy policy, and production testing still need to be implemented.

The sample job listings are demonstration data only.

## Open in Android Studio
1. Install Android Studio and Android SDK.
2. Extract this ZIP.
3. In Android Studio choose Open and select the `NaukriWala` folder.
4. Allow Gradle sync to finish.
5. Connect an Android phone with USB debugging enabled.
6. Select the phone and press Run.

## Important
- Package ID currently: `in.naukriwala.app`. Confirm availability before Play Store release.
- Target SDK is set to 36; re-check current Play Console requirements before submission.
- Do not publish this starter build as a finished job portal.
- Firebase must be configured before enabling real user accounts and data.
